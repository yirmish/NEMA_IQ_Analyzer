NEMA IQ Analyzer - demo dataset (digital phantom, no patient or site data)

Synthetic NEMA NU 2 image-quality test written by tests/digital_phantom.py: NU 2-2012 fill (10-22 mm spheres hot at
4:1, 28/37 mm cold), lung insert, 3 replicate acquisitions, 160 x 160 x 80 voxels of 2.5 mm, 6.5 mm PSF, noise.
Parameters: {'n': 160, 'px': 2.5, 'dz': 2.5, 'nz': 80, 'ss': 3, 'fwhm': 6.5, 'noise': 0.13, 'nrep': 3, 'fill': '2012', 'ratio': 4.0, 'lung_act': 0.09, 'tilt_deg': 0.5, 'rot_deg': 8.0, 'dx': 4.0, 'dy': -6.0, 'seed': 2012}
truth.json: true sphere centres (column/row/slice), phantom tilt and background concentration per replicate.

Use: open NEMA_IQ_Analyzer.html, drag this ZIP file (or the unpacked folder) onto the page, choose NEMA NU 2-2012
and click Analyse - or open https://yirmish.github.io/NEMA_IQ_Analyzer/NEMA_IQ_Analyzer.html?demo=1
